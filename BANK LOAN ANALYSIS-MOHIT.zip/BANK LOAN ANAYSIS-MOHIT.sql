--TASK-1:
create database loans;
use loans;

----Query to see all tables
select * 
from Banker;
select * 
from Customer;
select * 
from Home;
select * 
from Record;
-- all tables have been imported . AND Date format is also right(%y,%m,%d)

----Query to see DATA SCHEMA
select * 
from information_schema.tables;

--Query for see total no of rows in each tables.
select 'Banker' as Table_Name,count(*) as Total_no_of_Rows
from Banker
union
select 'Customer',count(*)
from Customer
union
select 'Home',count(*)
from Home
union
select 'Record',count(*)
from Record;

--Query to see the datatypes of columns in each tables.
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Banker';
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Customer';
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Home';
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Record';
--...........................................................................................

--Q1.Write a query to print all the databases available in SQL-Server?
select *
from sys.databases;

--Q2.Write a query to print the names of the Tables from the Loans Database?
select name
from sys.tables;

--Q3.Write a query to print 5 records in each Table?
select top(5)* 
from Banker;
select top(5)* 
from Customer;
select top(5)* 
from Home;
select top(5)* 
from Record;

/*=================================================================================================
TASK-2:
===================================================================================================*/

/*Q1.Find the ID,First name & Last name of the top 2 bankers (and corresponding transaction count);
involved in the highest number of distinct loan records? */
select top 2 b.banker_id,b.first_name,b.last_name ,count(distinct (r.loan_id)) as Transaction_Count
from Banker as b 
JOIN
Record as r
on b.banker_id=r.banker_id
group by b.banker_id,b.first_name,b.last_name
order by Transaction_Count DESC;

--Q2.Find number of home loan issued in San Francisco?
select 'San Francisco' as City_Name,count(*) as NO_of_Home_Loans
from Home
where city='San Francisco'

/*Q3.Find the city name and the corresponding average property value (using appropriate alias name);
for the city where the average property value is greater than $3,000,000.? */
select city as City_Name,avg(property_value) as Avg_Property_Value
from Home
group by city
having avg(property_value) > 3000000
order by Avg_Property_Value desc;

/*Q4.Find the maximum property value (using appropriate alias );of each property type,
ordered the maximum  property value in descending order.? */
select property_type,max(property_value) as Maximum_Property_Value
from Home
group by property_type
order by Maximum_Property_Value desc;

/*Q5.Find the average age of male bankers (years,rounded to 1 decimal place );
based on the date they joined WBG.? */
select gender,avg(datediff(YEAR,dob,date_joined )) as Avg_age
from Banker
where gender='Male'
group by gender;

/*Q6.Find the name of top 3 cities (based on descending alphabetical order );
and corresponding loan percent(in ascending order)with the lowest average loan percent.? */
select top 3 city,loan_percent
from home
group by city,loan_percent
having loan_percent<=avg(loan_percent)
order by city desc,loan_percent ;

/*Q7.Find the average loan term of loans not for semi-detached and townhome property types,
and are in the following list of cities: Sparks,Biloxi,Waco,Las Vegas,and Lansing? */
select  avg(loan_term) as Avg_Loan_Term
from home 
where property_type not in ('Semi-Detached','Townhome') 
and city in ('Sparks','Biloxi','Waco','Las Vegas','Lansing')

/*Q8.Find the average age ( at the point of loan transaction, in years and nearest interger )
of female customers who took a non-joint loan for townhomes.? */
select (sum((year(r.transaction_date)-year(c.dob)))/count((year(r.transaction_date)-year(c.dob)))) as AGE_AT_TX
from home as h  
join record as r
on h.loan_id=r.loan_id
join customer as c
on c.customer_id=r.customer_id
where c.gender ='Female' and h.joint_loan='0' and h.property_type='townhome';

/*Q9.Find the total number of different cities for which home loans have been issued? */
select count(distinct city) AS Total_Cities_With_HomeLoans
FROM Home;

/*Q10.Find the customer ID,first name,last name,email 
of customers whoes email adderss contains the term 'amazon'? */
select Customer_id,first_name,last_name,email
from Customer
where email like '%amazon%'
group by customer_id,first_name,last_name,email
order by customer_id;

/*=================================================================================================
TASK-3:
===================================================================================================*/

/*Q1.Find the ID and full name (first name concatenated with last name) of customers who 
were served by bankers aged below 30 (as of 1 Aug 2022).? */
select r.customer_id,CONCAT(c.first_name,' ',c.last_name) as Customer_Name
from Record as r
join banker as b on b.banker_id=r.banker_id
join Customer as c on c.customer_id=r.customer_id
where DATEDIFF(year,b.dob, '2022-08-01')<30;

/*Q2.Create a stored procedure called `city_and_above_loan_amt` that takes in 
two parameters (city_name, loan_amt_cutoff) that returns the full details of customers
with loans for properties in the input city and with loan amount greater than or equal to
the input loan amount cutoff.  
Call the stored procedure `city_and_above_loan_amt` you created above, 
based on the city San Francisco and loan amount cutoff of $1.5 million. */




/*Q3.Find the number of bankers involved in loans where the loan amount is greater than the average loan amount.?*/
SELECT COUNT(DISTINCT b.banker_id) AS num_bankers
FROM Banker as b
join Record as r on b.banker_id=r.banker_id
join Home as h on h.loan_id=r.loan_id
WHERE (property_value*0.01*loan_percent) >(sum(property_value*0.01*loan_percent)/count(r.loan_id) FROM loans);

/*Q4.Create a stored procedure called `recent_joiners` that returns the ID, concatenated full name, date of birth, 
and join date of bankers who joined within the recent 2 years (as of 1 Sep 2022).?
Call the stored procedure `recent_joiners` you created above. */
CREATE PROCEDURE  New_recent_joiners
AS
BEGIN
SELECT BANKER_id,CONCAT(first_name, ' ', last_name) AS full_name, dOB, DATE_JOINED
FROM Banker
WHERE DATE_JOINED >= '2020-09-01'
AND DATE_JOINED<= '2022-09-01'     --or DATEADD(YEAR, -2, '2022-09-01')
end;
--Accessing created procedure.
EXEC New_recent_joiners;

/*Q5.Find  the ID, first name and last name of customers with properties of value between $1.5 and $1.9 million, 
along with a new column 'tenure' that categorizes how long the customer has been with WBG.? 

The 'tenure' column is based on the following logic:
Long: Joined before 1 Jan 2015
Mid: Joined on or after 1 Jan 2015, but before 1 Jan 2019
Short: Joined on or after 1 Jan 2019.*/
SELECT c.customer_id, c.first_name,c.last_name,
CASE WHEN customer_since < '2015-01-01' THEN 'Long'
WHEN customer_since < '2019-01-01' THEN 'Mid'
ELSE 'Short' END AS tenure
FROM Customer as c
join Record as r on c.customer_id=r.customer_id
JOIN Home as h ON h.loan_id = r.loan_id
WHERE h.property_value BETWEEN 1500000 AND 1900000;

/*Q6.Create a view called `dallas_townhomes_gte_1m` which returns all the details of loans involving properties 
of townhome type, located in Dallas, and have loan amount of >$1 million.?*/
CREATE VIEW dallas_townhomes_gte_1m AS
SELECT
  h.loan_id,
  h.property_type,
  h.loan_percent,
  h.property_value,
  h.city,
  r.transaction_date
FROM
  Home as h
  JOIN Record as r ON h.loan_id = r.loan_id
WHERE
   (h.property_value*0.01*h.loan_percent) > 1000000;

--Accessing created procedure.
select* 
from dallas_townhomes_gte_1m ;

/*Q7.Find the number of Chinese customers with joint loans with property values less than $2.1 million, 
and served by female bankers.?*/
select count(c.customer_id)as Number_Of_Chinese_Customers
from Customer as c
join Record as r on c.customer_id=r.customer_id
join Banker as b on b.banker_id=r.banker_id
join Home as h on h.loan_id=r.loan_id
where c.nationality='china' and h.property_value<2100000 and b.gender='female' and h.joint_loan='1';

/*Q8.Find the top 3 transaction dates (and corresponding loan amount sum) for which the sum of loan amount 
issued on that date is the highest.?*/
select top 3 transaction_date, sum (property_value *0.01*loan_percent) AS loan_amount_sum
from Record as r
join Home as h
on h.loan_id=r.loan_id
group by transaction_date
order by loan_amount_sum desc;

/*Q9.Find the sum of the loan amounts ((i.e., property value x loan percent / 100) for each banker ID, excluding 
properties based in the cities of Dallas and Waco. The sum values should be rounded to nearest integer.?*/
select banker_id,round((h.property_value*0.01*h.loan_percent),0)as sum_loan_amount
from  Record as r
join Home as h on h.loan_id = r.loan_id
where city not in ('Dallas', 'Waco')



